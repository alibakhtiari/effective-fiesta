<br><br>

<p><strong>Simple</strong></p>
<nav class="nav-wrap">
	<a class="logo" href="#">My Brand</a>
	<div class="nav-menu">
		<ul class="nav">
			<li><a href="#">Home</a></li>
			<li><a href="#">About</a></li>
		</ul>
	</div>
</nav>

<br><br>

<p><strong>Expand-and-Collapse</strong></p>
<nav class="nav-wrap nav-collapse">
	<a class="logo" href="#">My Brand</a>
	<a class="nav-toggle" data-nav-toggle="#nav" href="#">Menu</a>
	<div class="nav-menu" id="nav">
		<ul class="nav">
			<li><a href="#">Home</a></li>
			<li><a href="#">About</a></li>
		</ul>
	</div>
</nav>

<br><br><br>