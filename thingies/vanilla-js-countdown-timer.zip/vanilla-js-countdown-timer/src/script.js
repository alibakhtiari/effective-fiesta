const oNow = new Date();
const oGoal = new Date(oNow.getUTCFullYear(), oNow.getMonth(), oNow.getDate(), 17, 0, 0, 0);
let mIntervalId = null;

mIntervalId = setInterval(function () {
	let oDiff = computeDateDiff(oGoal, new Date());
	updateUi(oDiff);
	if (isDone(oDiff)) {
		alert('Times up!');
		clearInterval(mIntervalId);
	}
}, 1000);

function computeDateDiff(oFirstDate, oSecondDate) {
	let oDiffMs = oFirstDate - oSecondDate;
	let iSeconds = Math.round(oDiffMs / 1000);
	let iHours = Math.floor(iSeconds / 3600);
	iSeconds = iSeconds % 3600;
	let iMinutes = Math.floor(iSeconds / 60);
	iSeconds = iSeconds % 60;
	return {
		hr: iHours,
		min: iMinutes,
		sec: iSeconds
	};
}

function isDone(oDiff) {
  return (oDiff.hr <= 0 && oDiff.min <= 0 && oDiff.sec <= 0);
}

function updateUi(oDiff) {
	document.querySelector('#hr').innerHTML = oDiff.hr + " hours";
	document.querySelector('#min').innerHTML = oDiff.min + " minutes";
	document.querySelector('#sec').innerHTML = oDiff.sec + " seconds";
}