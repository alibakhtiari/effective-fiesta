# Kraken
Kraken is a lightweight, mobile-first boilerplate for front-end web developers. [View the demo and get started](https://cferdinandi.github.io/kraken).


## License

The code is available under the [MIT License](LICENSE.md).